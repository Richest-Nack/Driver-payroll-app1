import { useState } from "react";

export default function App() {
  const [formData, setFormData] = useState({
    id: "",
    name: "",
    position: "คนขับรถ",
    phone: "",
    licensePlate: "",
    trips: "",
    remarks: "",
  });

  const [entries, setEntries] = useState([]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    const trips = parseInt(formData.trips) || 0;
    const fare = 800;
    const total = trips * fare;

    setEntries([
      ...entries,
      {
        ...formData,
        fare,
        total,
      },
    ]);

    setFormData({
      id: "",
      name: "",
      position: "คนขับรถ",
      phone: "",
      licensePlate: "",
      trips: "",
      remarks: "",
    });
  };

  const exportToExcel = () => {
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [
        [
          "รหัสพนักงาน",
          "ชื่อ-สกุล",
          "ตำแหน่ง",
          "เบอร์โทร",
          "ทะเบียนรถ",
          "จำนวนเที่ยว/วัน",
          "ค่าเที่ยว (บาท)",
          "รวมค่าจ้าง/วัน (บาท)",
          "หมายเหตุ",
        ].join(",") +
          "\n" +
          entries
            .map((e) =>
              [
                e.id,
                e.name,
                e.position,
                e.phone,
                e.licensePlate,
                e.trips,
                e.fare,
                e.total,
                e.remarks,
              ].join(",")
            )
            .join("\n"),
      ];

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "driver_data.csv");
    document.body.appendChild(link);
    link.click();
  };

  return (
    <div style={{ maxWidth: 800, margin: "auto", padding: 20 }}>
      <h2>Driver Payroll Form</h2>
      <div style={{ display: "grid", gap: 10 }}>
        <input name="id" placeholder="รหัสพนักงาน" value={formData.id} onChange={handleChange} />
        <input name="name" placeholder="ชื่อ-สกุล" value={formData.name} onChange={handleChange} />
        <input name="phone" placeholder="เบอร์โทร" value={formData.phone} onChange={handleChange} />
        <input name="licensePlate" placeholder="ทะเบียนรถ" value={formData.licensePlate} onChange={handleChange} />
        <input name="trips" placeholder="จำนวนเที่ยว/วัน" value={formData.trips} onChange={handleChange} />
        <input name="remarks" placeholder="หมายเหตุ" value={formData.remarks} onChange={handleChange} />
        <button onClick={handleSubmit}>เพิ่มข้อมูล</button>
      </div>

      <h3 style={{ marginTop: 30 }}>รายการพนักงาน</h3>
      <table border="1" cellPadding="5" style={{ width: "100%", marginTop: 10 }}>
        <thead>
          <tr>
            <th>รหัส</th><th>ชื่อ</th><th>ตำแหน่ง</th><th>โทร</th><th>ทะเบียน</th><th>เที่ยว</th><th>ค่าเที่ยว</th><th>รวม</th><th>หมายเหตุ</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((e, i) => (
            <tr key={i}>
              <td>{e.id}</td><td>{e.name}</td><td>{e.position}</td><td>{e.phone}</td>
              <td>{e.licensePlate}</td><td>{e.trips}</td><td>{e.fare}</td><td>{e.total}</td><td>{e.remarks}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <button onClick={exportToExcel} style={{ marginTop: 20 }}>ส่งออก Excel</button>
    </div>
  );
}
